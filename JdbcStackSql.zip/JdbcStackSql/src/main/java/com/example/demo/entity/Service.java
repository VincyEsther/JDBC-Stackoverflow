package com.example.demo.entity;

public class Service {
	private ServiceContract servicecontract;

	public Service() {
		super();
	}

	public ServiceContract getServicecontract() {
		return servicecontract;
	}

	public void setServicecontract(ServiceContract servicecontract) {
		this.servicecontract = servicecontract;
	}
	
	
}
