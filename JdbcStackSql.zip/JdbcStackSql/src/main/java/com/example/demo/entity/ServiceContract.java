package com.example.demo.entity;

public class ServiceContract {
	private QuestionResponse questionResponse;

	public ServiceContract() {
		super();
	}

	public QuestionResponse getQuestionResponse() {
		return questionResponse;
	}

	public void setQuestionResponse(QuestionResponse questionResponse) {
		this.questionResponse = questionResponse;
	}
	
}
