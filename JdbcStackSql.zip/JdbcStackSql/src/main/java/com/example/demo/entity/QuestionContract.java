package com.example.demo.entity;

public class QuestionContract {
	private QuestionsResponse questionsResponse;

	public QuestionContract() {
		super();
	}

	public QuestionsResponse getQuestionsResponse() {
		return questionsResponse;
	}

	public void setQuestionsResponse(QuestionsResponse questionsResponse) {
		this.questionsResponse = questionsResponse;
	}
	

}
