package com.example.demo.entity;

public class QuestionDetails {
	private QuestionsList questionsList;
	
	public QuestionDetails() {
		super();
	}
	public QuestionsList getQuestionsList() {
		return questionsList;
	}
	public void setQuestionsList(QuestionsList questionsList) {
		this.questionsList = questionsList;
	}
	
}
