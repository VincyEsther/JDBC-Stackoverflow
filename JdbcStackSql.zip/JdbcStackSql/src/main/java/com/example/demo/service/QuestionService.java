package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.demo.dao.QuestionDao;
import com.example.demo.entity.AnswerDetailsList;
import com.example.demo.entity.PagingList;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.ServiceContract;

@Service
public class QuestionService {
	@Autowired
	private QuestionDao questiondao;
	
	public List<QuestionsList> getAllQuestions( int pageNumber,  int pageSize){
        Pageable paging = PageRequest.of(pageNumber, pageSize);
                
                List<QuestionsList> getallPage = questiondao.getAllQuestions();
                
                int start = Math.min((int)paging.getOffset(), getallPage.size());
                int end = Math.min((start + paging.getPageSize()), getallPage.size());
                
                Page<QuestionsList> page = new PageImpl<>(getallPage.subList(start, end), paging, getallPage.size());
                        return page.getContent();                  
            }
	public List<PagingList> pagination(int pageNumber,int totalnumberofpages){
        List<PagingList> pagelist = new ArrayList<>();
        PagingList page = new PagingList();
        if(pageNumber==0 && totalnumberofpages==1) {
        	
            page.setId("current");
           page.setPagenumber(pageNumber);
  
           pagelist.add(page);
  }           
        else if(pageNumber==0) {
        	
             page.setId("current");
            page.setPagenumber(pageNumber);
            
            PagingList page1 = new PagingList();
            page1.setId("next");
            page1.setPagenumber((pageNumber+1));
            
            pagelist.add(page);
            pagelist.add(page1);
   }     
        else if(pageNumber<totalnumberofpages-1){
           
            page.setId("current");
            page.setPagenumber(pageNumber);
            
            PagingList page1 = new PagingList();
            page1.setId("next");
            page1.setPagenumber((pageNumber+1));
            
            PagingList page2 = new PagingList();
            page2.setId("previous");
            page2.setPagenumber((pageNumber-1));

            pagelist.add(page2);
            pagelist.add(page);
            pagelist.add(page1);
    }
        
        else {
        	page.setId("current");
            page.setPagenumber(pageNumber);
            
            PagingList page2 = new PagingList();
            page2.setId("previous");
            page2.setPagenumber((pageNumber-1));
            
            pagelist.add(page2);
            pagelist.add(page);
        
        } 
        return pagelist;
    }

	public QuestionsList getQuestionsById(int questionid) {
		return questiondao.getQuestionsById(questionid);
	}
	public ServiceContract addQuestion(ServiceContract servicecontract) {
		return questiondao.addQuestion(servicecontract);
	}
	public QuestionsList updateQuestion(QuestionsList questionname) {
		return questiondao.updateQuestion(questionname);
	}
	public QuestionsList deleteQuestion(int questionid) {
		return questiondao.deleteQuestion(questionid);
	}
	public int count(){
		return questiondao.count();
	}
	public int countanswers() {
		return questiondao.countanswers();
	}
	public List<AnswerDetailsList> getAnswers(int questionid)  {
		return questiondao.getAnswers(questionid);
	}
	public List<AnswerDetailsList> getAllAnswers(){
		return questiondao.getAllAnswers();
	}
}
