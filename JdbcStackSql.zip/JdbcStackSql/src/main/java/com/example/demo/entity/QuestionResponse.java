package com.example.demo.entity;

public class QuestionResponse {
	private QuestionDetails questionDetails;
	private AnswerDetails answerDetails;
	public QuestionResponse() {
		super();
	}
	public QuestionDetails getQuestionDetails() {
		return questionDetails;
	}
	public void setQuestionDetails(QuestionDetails questionDetails) {
		this.questionDetails = questionDetails;
	}
	public AnswerDetails getAnswerDetails() {
		return answerDetails;
	}
	public void setAnswerDetails(AnswerDetails answerDetails) {
		this.answerDetails = answerDetails;
	}

}
