package com.example.demo.entity;

public class AnswerDetailsList {
	private int answerid;
	private String answerbody;
	private String comments;
	public AnswerDetailsList() {
		super();
	}
	public int getAnswerid() {
		return answerid;
	}
	public void setAnswerid(int answerid) {
		this.answerid = answerid;
	}
	public String getAnswerbody() {
		return answerbody;
	}
	public void setAnswerbody(String answerbody) {
		this.answerbody = answerbody;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	

}
