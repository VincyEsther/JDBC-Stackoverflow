package com.example.demo.entity;

public class QuestionsResponse {
	private Questions questions;
	private PagingDetails  pagingDetails;
	
	public QuestionsResponse() {
		super();
	}

	public Questions getQuestions() {
		return questions;
	}

	public void setQuestions(Questions questions) {
		this.questions = questions;
	}

	public PagingDetails getPagingDetails() {
		return pagingDetails;
	}

	public void setPagingDetails(PagingDetails pagingDetails) {
		this.pagingDetails = pagingDetails;
	}

}
