package com.example.demo.dao;

import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.AnswerDetailsList;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.ServiceContract;
import com.example.demo.mapper.QuestionsMapper;

@Repository
public class QuestionDao {
	@Autowired
    JdbcTemplate jdbctemplate;

	public List<QuestionsList> getAllQuestions() {
        return jdbctemplate.query("select * from questioncontract", new QuestionsMapper());
       
  }
   public QuestionsList getQuestionsById(int questionid) {
       return jdbctemplate.queryForObject("SELECT * FROM questioncontract WHERE questionid=?",new QuestionsMapper(),questionid);
               
   }
   public ServiceContract addQuestion(ServiceContract servicecontract) {
	    jdbctemplate.update("INSERT INTO questioncontract (questionid, questionname, description, numberofvotes, numberofviews,"
	   		+ "numberofanswers, createdon, field1,field2, username, reputationscore, numberofgoldbadges, "
	   		+ "numberofbronzebadges, numberofsilverbadges) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionid(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionname(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getDescription(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getNumberofvotes(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getNumberofviews(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getNumberofanswers(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getCreatedon(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getTagsList().getField1(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getTagsList().getField1(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getUsersDetails().getUsername(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getUsersDetails().getReputationscore(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getUsersDetails().getNumberofgoldbadges(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getUsersDetails().getNumberofbronzebadges(),
	   		servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getUsersDetails().getNumberofsilverbadges());
		return servicecontract;
		 
   }
   public QuestionsList updateQuestion(QuestionsList questionname) {
	   jdbctemplate.update("UPDATE questioncontract SET questionname=?,modifiedon=? WHERE questionid = ?",
	   		questionname.getQuestionname(),questionname.getModifiedon(),
	   		questionname.getQuestionid());
	   return getQuestionsById(questionname.getQuestionid());
   }
   public QuestionsList deleteQuestion(int questionid) {
	   jdbctemplate.update("delete from questioncontract where questionid=?",questionid);
	   return null;
   }
   public int count() {
	   return jdbctemplate.queryForObject(
			   "SELECT COUNT(*) FROM questioncontract", Integer.class);
}
   public int countanswers() {
	   return jdbctemplate.queryForObject("select count(*) from answerdetails", Integer.class);
   }
public List<AnswerDetailsList> getAnswers(int questionid) {
	 return jdbctemplate.query("SELECT answerid,answerbody,numberofvotes,comments FROM  answerdetails f   WHERE f.questionId = ?",
					 new Object[] { questionid },new int[] { Types.VARCHAR },new BeanPropertyRowMapper<AnswerDetailsList>(AnswerDetailsList.class));   
 }

public List<AnswerDetailsList> getAllAnswers(){
	 return jdbctemplate.query("select * from answerdetails", new BeanPropertyRowMapper<AnswerDetailsList>(AnswerDetailsList.class));
 }
 
}
