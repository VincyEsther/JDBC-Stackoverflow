package com.example.demo.entity;

public class Response {
	
	private Message message;
	
	public Response() {
		super();
	}
	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

}
