package com.example.demo.entity;

import java.util.List;

public class Answers {
	private int numberOfAnswers;
	private List<AnswerDetailsList> answerDetailsList;
	public Answers() {
		super();
	}
	public int getNumberOfAnswers() {
		return numberOfAnswers;
	}
	public void setNumberOfAnswers(int numberOfAnswers) {
		this.numberOfAnswers = numberOfAnswers;
	}
	public List<AnswerDetailsList> getAnswerDetailsList() {
		return answerDetailsList;
	}
	public void setAnswerDetailsList(List<AnswerDetailsList> answerDetailsList) {
		this.answerDetailsList = answerDetailsList;
	}

	
}
