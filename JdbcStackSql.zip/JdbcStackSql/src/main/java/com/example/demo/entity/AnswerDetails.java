package com.example.demo.entity;

public class AnswerDetails {
	private Answers answers;

	public AnswerDetails() {
		super();
	}
	public Answers getAnswers() {
		return answers;
	}

	public void setAnswers(Answers answers) {
		this.answers = answers;
	}
	

}
