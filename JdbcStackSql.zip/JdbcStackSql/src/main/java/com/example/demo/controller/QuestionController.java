package com.example.demo.controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.AnswerDetails;
import com.example.demo.entity.AnswerDetailsList;
import com.example.demo.entity.Answers;
import com.example.demo.entity.Message;
import com.example.demo.entity.PagingDetails;
import com.example.demo.entity.PagingList;
import com.example.demo.entity.QuestionContract;
import com.example.demo.entity.QuestionDetails;
import com.example.demo.entity.QuestionResponse;
import com.example.demo.entity.Questions;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.QuestionsResponse;
import com.example.demo.entity.Response;
import com.example.demo.entity.Service;
import com.example.demo.entity.ServiceContract;
import com.example.demo.service.QuestionService;


@RequestMapping("/questioncontract")
@RestController
public class QuestionController {
	@Autowired
    private QuestionService questionservice;
	
	@GetMapping("/getAllQuestions")
    public ResponseEntity<Object> getAllQuestions(
            @RequestParam(value = "pageNumber" , defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize" , defaultValue = "2", required = false) int pageSize){
		QuestionContract questionContract=new QuestionContract();
        Questions questions=new Questions();
        QuestionsResponse questionsResponse=new QuestionsResponse();
        PagingDetails pagingdetails=new PagingDetails();
        int numberOfQuestions=questionservice.count();
        pagingdetails.setTotalnumberofpages(numberOfQuestions,pageSize);
        int totalnumberofpages=pagingdetails.getTotalnumberofpages();
        if(pageNumber>=totalnumberofpages) {
        	Response response = new Response();
	        Message message = new Message();
	        message.setCode(404);
	        message.setType("Not Found");
	        message.setDescription("Page Number Not Found");
	        response.setMessage(message);
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
        else {
        List<QuestionsList> questionsList=questionservice.getAllQuestions(pageNumber,pageSize);
        List<PagingList> paginglist=questionservice.pagination(pageNumber,pagingdetails.getTotalnumberofpages());
        pagingdetails.setLimits(pageSize);
        pagingdetails.setPagingList(paginglist);
        questionsResponse.setQuestions(questions);
        questionsResponse.setPagingDetails(pagingdetails);
        questions.setNumberOfQuestions(numberOfQuestions);
        questions.setQuestionsList(questionsList);
        questionContract.setQuestionsResponse(questionsResponse);
        return new ResponseEntity<>(questionContract,HttpStatus.OK);
        }
    }
	
	@GetMapping("/getQuestionsById/{questionid}")
	public ResponseEntity<Object> getQuestionsById(@PathVariable int questionid){
		try {
			QuestionDetails questiondetails=new QuestionDetails();
			QuestionResponse questionresponse=new QuestionResponse();
			ServiceContract servicecontract=new ServiceContract();
	        Answers answers=new Answers();
	        AnswerDetails answerdetails=new AnswerDetails();
	        QuestionsList getQuestionsById  = questionservice.getQuestionsById(questionid);
	        int numberofanswers=questionservice.countanswers();
	        List<AnswerDetailsList> answerdetailslist=questionservice.getAnswers(questionid);
	        questiondetails.setQuestionsList(getQuestionsById);
	        questionresponse.setQuestionDetails(questiondetails);
	        answers.setNumberOfAnswers(numberofanswers);
	        answers.setAnswerDetailsList(answerdetailslist);
	        answerdetails.setAnswers(answers);
	        questionresponse.setAnswerDetails(answerdetails);
	        servicecontract.setQuestionResponse(questionresponse);
	     return new ResponseEntity<>(servicecontract, HttpStatus.OK);
	    }
	    catch(Exception e) {
	        Response response = new Response();
	        Message message = new Message();
	        message.setCode(404);
	        message.setType("Not Found");
	        message.setDescription("ID Not Found");
	        response.setMessage(message);
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
	}
	@PostMapping("/addQuestions")
	public ResponseEntity<Object> addQuestion(@RequestBody ServiceContract servicecontract){
	if(servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionid()==0||servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionname()==null )
    {
        Response response = new Response();
        Message message = new Message();
        message.setCode(400);
        message.setType("Bad Request");
        message.setDescription("Invalid Request");
        response.setMessage(message);
       return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
  
    }
	try {
        questionservice.getQuestionsById(servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionid());
        Message message = new Message();
        Response response = new Response();
        message.setCode(409);
        message.setDescription("Id already present in database");
        message.setType("CONFLICT");
        response.setMessage(message);
        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
    } catch (Exception e) { 
        Service service=new Service();
        Date date=new Date();
        SimpleDateFormat dateForm=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        servicecontract.getQuestionResponse().getQuestionDetails().getQuestionsList().setCreatedon(dateForm.format(date)); 
        questionservice.addQuestion(servicecontract);
          service.setServicecontract(servicecontract);
         return new ResponseEntity<>(servicecontract, HttpStatus.CREATED);
    }
	}
	@PutMapping("/editquestions")
    public ResponseEntity<Object> updateQuestion(@RequestBody QuestionsList questionname){
		if(questionname.getQuestionid()==0||questionname.getQuestionname()==null) {
			Message message = new Message();
            Response response = new Response();
            message.setCode(400);
			message.setType("Bad Request");
			message.setDescription("Invalid Request");
            response.setMessage(message);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		} 
       try {
            questionname.getQuestionid();
            QuestionDetails questiondetails=new QuestionDetails();
            questionservice.getQuestionsById(questionname.getQuestionid());
            Date date=new Date();
            SimpleDateFormat dateForm=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            questionname.setModifiedon(dateForm.format(date));
            QuestionsList updateQuestions=questionservice.updateQuestion(questionname);
            questiondetails.setQuestionsList(updateQuestions);
            return new ResponseEntity<>(questiondetails,HttpStatus.OK);
        }
        catch(Exception e) {
            Response response = new Response();
            Message message = new Message();
            message.setCode(404);
            message.setType("Not Found");
            message.setDescription("ID Not Found");
            response.setMessage(message);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }       
    }
	@DeleteMapping("/deletequestions/{questionid}")
    public ResponseEntity<Response> deleteQuestion(@PathVariable int questionid)
    {
        try {
            Response response=new Response();
            Message message=new Message();
            questionservice.deleteQuestion(questionid);
           message.setCode(200);
            message.setType("200 OK");
            message.setDescription("Deleted Successfully");
            response.setMessage(message);
            
        return new ResponseEntity<>(response,HttpStatus.OK);
        }
        catch(Exception e)
        
        {
            Response response=new Response();
            Message message= new Message();
            message.setCode(200);
            message.setType("Deleting");
            message.setDescription(" this question is already deleted");
            response.setMessage(message);
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
        }
}
