package com.example.demo.entity;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class QuestionsTest {
	@Test
	void QuestionTest() {
		Questions questions=new Questions();
		ArrayList<QuestionsList> questionsList=new ArrayList<>();
		questions.setNumberOfQuestions(3);
		questions.setQuestionsList(questionsList);
		assertEquals(3,questions.getNumberOfQuestions());
		assertEquals(questionsList,questions.getQuestionsList());
		
	}

}
