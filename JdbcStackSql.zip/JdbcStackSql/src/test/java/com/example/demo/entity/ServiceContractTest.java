package com.example.demo.entity;

import org.junit.jupiter.api.Test;

class ServiceContractTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testServiceContract() {
		ServiceContract servicecontract=new ServiceContract();
		QuestionResponse questionresponse=new QuestionResponse();
		servicecontract.setQuestionResponse(questionresponse);
		equals(servicecontract.getQuestionResponse());
	}

}
