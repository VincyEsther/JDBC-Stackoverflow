package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class PagingListTest {

	@Test
	void testPagingList() {
		PagingList paginglist=new PagingList();
		paginglist.setId("current");
		paginglist.setPagenumber(2);
		assertEquals("current",paginglist.getId());
		assertEquals(2,paginglist.getPagenumber());
	}

}
