package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ServiceTest {

	@Test
	void test() {
		ServiceContract servicecontract=new ServiceContract();
		Service service=new Service();
		service.setServicecontract(servicecontract);
		assertEquals(servicecontract,service.getServicecontract());
	}

}
