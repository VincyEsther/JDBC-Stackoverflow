package com.example.demo.entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class QuestionDetailsTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testQuestionDetails() {
		QuestionDetails questionDetails=new QuestionDetails();
		QuestionsList questionslist=new QuestionsList();
		questionDetails.setQuestionsList(questionslist);
		equals(questionDetails.getQuestionsList());
	}

}
