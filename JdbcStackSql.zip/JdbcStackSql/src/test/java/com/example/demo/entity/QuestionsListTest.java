package com.example.demo.entity;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class QuestionsListTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testQuestionsList() {
		QuestionsList questionslist=new QuestionsList();
		TagsList tl=new TagsList();
		UserDetails userdetails = new UserDetails();
		questionslist.setQuestionid(1);
		questionslist.setQuestionname("what is sql");
		questionslist.setDescription("Sql");
		questionslist.setNumberofvotes(55);
		questionslist.setNumberofviews(34);
		questionslist.setNumberofanswers(44);
		tl.setField1("sql");
		tl.setField2("sql-server");
		userdetails.setUsername("vinz");
      userdetails.setReputationscore(85);
      userdetails.setNumberofgoldbadges(68);
      userdetails.setNumberofbronzebadges(46);
      userdetails.setNumberofsilverbadges(65);
      questionslist.setUsersDetails(userdetails);
		equals(questionslist.getQuestionid());
		equals(questionslist.getQuestionname());
		equals(questionslist.getDescription());
		equals(questionslist.getNumberofvotes());
		equals(questionslist.getNumberofviews());
		equals(questionslist.getNumberofanswers());
		equals(questionslist.getCreatedon());
		equals(questionslist.getTagsList());
		equals(questionslist.getUsersDetails());

				
	}

}
