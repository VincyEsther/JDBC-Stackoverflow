package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class QuestionsResponseTest {

	@Test
	void testQuestionsResponse() {
		QuestionsResponse questionsresponse=new QuestionsResponse();
		Questions questions=new Questions();
		PagingDetails pagingDetails=new PagingDetails();
		questionsresponse.setQuestions(questions);
		questionsresponse.setPagingDetails(pagingDetails);
		assertEquals(questions,questionsresponse.getQuestions());
		assertEquals(pagingDetails,questionsresponse.getPagingDetails());
	}

}
