package com.example.demo.mapper;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.QuestionContract;
import com.example.demo.entity.QuestionDetails;
import com.example.demo.entity.Questions;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.QuestionsResponse;
import com.example.demo.entity.TagsList;
import com.example.demo.entity.UserDetails;
@SpringBootTest
class QuestionsMapperTest {

	@InjectMocks
	private QuestionsMapper questionmapper;
	@Test
	 void testQuestionsMapper()throws SQLException{
		QuestionContract questionContract=new QuestionContract();
        Questions questions = new Questions();
        QuestionsResponse questionresponse = new QuestionsResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();
        ResultSet resultSet = mock(ResultSet.class);
		questionlist.setQuestionid(1);
        questionlist.setQuestionname("What is java");
        questionlist.setDescription("Java is programing Language");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("John");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        questiondetails.setQuestionsList(questionlist);
        questionresponse.setQuestions(questions);
        questionContract.setQuestionsResponse(questionresponse);
        when(questionmapper.mapRow(resultSet, 1)).thenReturn(questionlist);
        verify(questionmapper.mapRow(resultSet, 1));
	}

	

}
