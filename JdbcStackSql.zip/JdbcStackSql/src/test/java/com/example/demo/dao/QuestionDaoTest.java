package com.example.demo.dao;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.example.demo.entity.AnswerDetails;
import com.example.demo.entity.AnswerDetailsList;
import com.example.demo.entity.Answers;
import com.example.demo.entity.QuestionDetails;
import com.example.demo.entity.QuestionResponse;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.Service;
import com.example.demo.entity.ServiceContract;
import com.example.demo.entity.TagsList;
import com.example.demo.entity.UserDetails;
@SpringBootTest
class QuestionDaoTest {
	
	@InjectMocks
	private QuestionDao questiondao;
	
	@Mock
	JdbcTemplate jdbctemplate;
	
	
	@SuppressWarnings("unchecked")
	@Test
    void testGetAllQuestion() throws DataAccessException {
        ArrayList<QuestionsList> questionListList = new ArrayList<>();
        when(jdbctemplate.query((String) any(), (RowMapper<QuestionsList>) any())).thenReturn(questionListList);
        List<QuestionsList> actualAllQuestion = questiondao.getAllQuestions();
        assertEquals(questionListList, actualAllQuestion);
        assertTrue(actualAllQuestion.isEmpty());
        verify(jdbctemplate).query((String) any(), (RowMapper<QuestionsList>) any());
    }
	
	@SuppressWarnings("unused")
    @Test
    void getByIdTest()throws DataAccessException {
		ServiceContract servicecontract = new ServiceContract();
        QuestionResponse questionresponse = new QuestionResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questiondetaillist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();



       questionlist.setQuestionid(1);
        questionlist.setQuestionname("What is java");
        questionlist.setDescription("Java is programing Language");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("John");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        questiondetails.setQuestionsList(questionlist);
        questionresponse.setQuestionDetails(questiondetails);
        servicecontract.setQuestionResponse(questionresponse);
      when(questiondao.getQuestionsById(questionlist.getQuestionid())).thenReturn(questionlist);
       //assertEquals(questionlist,questionService.getById(questionlist.getQuestionId()));
      questiondao.getQuestionsById(questionlist.getQuestionid());
   }
	@Test
	void testAddQuestion()throws DataAccessException{
		ServiceContract servicecontract=new ServiceContract();
		QuestionDetails questiondetails=new QuestionDetails();
		QuestionResponse questionresponse=new QuestionResponse();
		Service service=new Service();
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(11);
		questionsList.setQuestionname("what is SQL");
		questionsList.setDescription("Questions based on SQL");
		questionsList.setNumberofvotes(21);
		questionsList.setNumberofviews(22);
		questionsList.setNumberofanswers(23);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("vincy",12,23,24,25));
		questiondetails.setQuestionsList(questionsList);
		questionresponse.setQuestionDetails(questiondetails);
		servicecontract.setQuestionResponse(questionresponse);
		service.setServicecontract(servicecontract); 
		when(questiondao.addQuestion(servicecontract)).thenReturn(servicecontract);
		questiondao.addQuestion(servicecontract);
	}
	@SuppressWarnings("unused")
	@Test
	void testUpdateQuestion() throws DataAccessException{
		QuestionResponse questionresponse = new QuestionResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questiondetaillist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();

       questionlist.setQuestionid(1);
        questionlist.setQuestionname("What is java");
        questionlist.setDescription("Java is programing Language");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("John");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
		
		when(questiondao.updateQuestion(questionlist)).thenReturn(questionlist);
		questiondao.updateQuestion(questionlist);
	}
	

	@SuppressWarnings("unused")
	@Test
	void testDeleteQuestion()throws DataAccessException{
		QuestionResponse questionresponse = new QuestionResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questiondetaillist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();

       questionlist.setQuestionid(1);
        questionlist.setQuestionname("What is java");
        questionlist.setDescription("Java is programing Language");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("John");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        when(jdbctemplate.update("DELETE FROM questioncontract WHERE QUESTIONID=?")).thenReturn(1);
        questiondao.deleteQuestion(1);
	}
	@Test
	void testquestionCount()throws DataAccessException{
		int questionlist = questiondao.count();
		when(jdbctemplate.queryForObject("SELECT COUNT(*) FROM questioncontract", Integer.class)).thenReturn(questionlist);
		verify(jdbctemplate).queryForObject((String) any(), Integer.class);
	}
	
	@Test
	void testanswerCount()throws DataAccessException{
		int answerdetaillist=questiondao.countanswers();
		when(jdbctemplate.queryForObject("select count(*) from answerdetails", Integer.class)).thenReturn(answerdetaillist);
		verify(jdbctemplate).queryForObject((String) any(), Integer.class);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void testAnswersById()throws DataAccessException{
		Answers answers=new Answers();
		AnswerDetails answerdetails=new AnswerDetails();
		AnswerDetailsList answerdetaillist=new AnswerDetailsList();
		ArrayList<AnswerDetailsList> answerlist=new ArrayList<>();
		answerdetaillist.setAnswerid(1);
		answerdetaillist.setAnswerbody("Java Program");
		answerdetaillist.setComments("Question based on java");
		answers.setAnswerDetailsList(answerlist);
		answerdetails.setAnswers(answers);
		when(jdbctemplate.query((String) any(), (BeanPropertyRowMapper<AnswerDetailsList>) any())).thenReturn(answerlist);
		List<AnswerDetailsList> actualAllQuestion =questiondao.getAnswers(answerdetaillist.getAnswerid());
		assertEquals(answerlist,actualAllQuestion);
		assertTrue(actualAllQuestion.isEmpty());
//		verify(jdbctemplate).query((String) any(), (BeanPropertyRowMapper<AnswerDetailsList>) any());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void testAllAnswers()throws DataAccessException{
		ArrayList<AnswerDetailsList> answerslist = new ArrayList<>();
        when(jdbctemplate.query((String) any(), (BeanPropertyRowMapper<AnswerDetailsList>) any())).thenReturn(answerslist);
        List<AnswerDetailsList> actualAllQuestion = questiondao.getAllAnswers();
        assertEquals(answerslist, actualAllQuestion);
        assertTrue(actualAllQuestion.isEmpty());
        verify(jdbctemplate).query((String) any(), (BeanPropertyRowMapper<AnswerDetailsList>) any());
		
	}
	
		
}
