package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TagsListTest {

	@Test
    void testDefaultConstructor() {
        TagsList tagsList = new TagsList();
        tagsList.setField1("sql");
        tagsList.setField2("my-sql");
        assertEquals("sql",tagsList.getField1());
        assertEquals("my-sql",tagsList.getField2());
    }

}
