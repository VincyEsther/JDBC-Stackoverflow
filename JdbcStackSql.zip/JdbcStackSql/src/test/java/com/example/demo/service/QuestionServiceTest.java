package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.dao.QuestionDao;
import com.example.demo.entity.AnswerDetailsList;
import com.example.demo.entity.PagingList;
import com.example.demo.entity.QuestionDetails;
import com.example.demo.entity.QuestionResponse;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.Service;
import com.example.demo.entity.ServiceContract;
import com.example.demo.entity.TagsList;
import com.example.demo.entity.UserDetails;
@SpringBootTest
class QuestionServiceTest {

	@InjectMocks
	private QuestionService questionservice;
	@Mock 
	private QuestionDao questiondao;
	
	
	@Test
	void getAllQuestionsTest() {
		ArrayList<QuestionsList> questionsList=new ArrayList<>();
		when(questiondao.getAllQuestions()).thenReturn(questionsList);
		List<QuestionsList> question=questionservice.getAllQuestions(1, 1);
		assertEquals(questionsList,question);
	}
//	@Test
//	void paginationTest() {
//		PagingList page = new PagingList();
//		ArrayList<PagingList> pagingList=new ArrayList<>();
//		page.setId("Current");
//		page.setPagenumber(3);
//		when(questionservice.pagination(page.getPagenumber())).thenReturn(pagingList);
////		assertEquals(pagingList,questionservice.pagination(page.getPagenumber()));		
//	}
	@Test
    void getPaginationTest()
    {
        List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList previouspage = new PagingList();
       // int pageSize=1;
        int pageNumber=0;
        currentPage.setId("CURRENT");
        currentPage.setPagenumber(pageNumber);          
       
        previouspage.setId("previous");
        previouspage.setPagenumber((pageNumber-1));
        
        pagelist.add(currentPage);
        pagelist.add(previouspage);
       
        
        questionservice.pagination(4,4);
        
    }
	@Test
    void getPaginationTest1()
    {
        List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList previouspage = new PagingList();
        PagingList nextPage = new PagingList();
       // int pageSize=1;
        int pageNumber=0;
        currentPage.setId("CURRENT");
        currentPage.setPagenumber(pageNumber);          
       
        previouspage.setId("previous");
        previouspage.setPagenumber((pageNumber-1));
        nextPage.setId("NEXT");
        nextPage.setPagenumber((pageNumber+1));
        
        pagelist.add(currentPage);
        pagelist.add(previouspage);
        pagelist.add(nextPage);
       
        
        questionservice.pagination(2,4);
        
    }
    
    @Test
    void getPaginationTest2()
    {
        List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList nextPage = new PagingList();
       // int pageSize=1;
        int pageNumber=1;
        currentPage.setId("CURRENT");
        currentPage.setPagenumber(pageNumber);          
       
        nextPage.setId("NEXT");
        nextPage.setPagenumber((pageNumber+1));
        
        pagelist.add(currentPage);
        pagelist.add(nextPage);
       
        
        questionservice.pagination(0, 5);
        
    }
	
	@Test
	void getQuestionsByIdTest() {
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(11);
		questionsList.setQuestionname("what is SQL");
		questionsList.setDescription("Questions based on SQL");
		questionsList.setNumberofvotes(21);
		questionsList.setNumberofviews(22);
		questionsList.setNumberofanswers(23);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("vincy",12,23,24,25));
		when(questiondao.getQuestionsById(11)).thenReturn(questionsList);
		assertEquals(questionsList,questionservice.getQuestionsById(questionsList.getQuestionid()));
		}
	
	@Test
	void addQuestionsTest() {
		ServiceContract servicecontract=new ServiceContract();
		QuestionDetails questiondetails=new QuestionDetails();
		QuestionResponse questionresponse=new QuestionResponse();
		Service service=new Service();
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(11);
		questionsList.setQuestionname("what is SQL");
		questionsList.setDescription("Questions based on SQL");
		questionsList.setNumberofvotes(21);
		questionsList.setNumberofviews(22);
		questionsList.setNumberofanswers(23);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("vincy",12,23,24,25));
		questiondetails.setQuestionsList(questionsList);
		questionresponse.setQuestionDetails(questiondetails);
		servicecontract.setQuestionResponse(questionresponse);
		service.setServicecontract(servicecontract);
		when(questiondao.addQuestion(servicecontract)).thenReturn(servicecontract);
		assertEquals(servicecontract,questionservice.addQuestion(servicecontract));		
	}
	

	@Test
	void updateQuestionTest() {
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(14);
		questionsList.setQuestionname("what is Oops");
		questionsList.setDescription("Questions based on Oops");
		questionsList.setNumberofvotes(41);
		questionsList.setNumberofviews(42);
		questionsList.setNumberofanswers(43);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("Sandy",35,13,44,25));
		when(questiondao.updateQuestion(questionsList)).thenReturn(questionsList);
		assertEquals(questionsList,questionservice.updateQuestion(questionsList));
	}
	
	@Test
	void deleteQuestionTest() {
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(15);
		questionsList.setQuestionname("what is Inheritance");
		questionsList.setDescription("Questions based on Inheritance");
		questionsList.setNumberofvotes(45);
		questionsList.setNumberofviews(46);
		questionsList.setNumberofanswers(43);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("Kumar",25,11,34,25));
		when(questiondao.deleteQuestion(15)).thenReturn(questionsList);
		assertEquals(questionsList,questionservice.deleteQuestion(questionsList.getQuestionid()));
		
	}
	@Test
	void questionCountTest() {
		int questionsList=questionservice.count();
		when(questiondao.count()).thenReturn(questionsList);
		assertEquals(questionsList,questionservice.count());
	}
	
	@Test
	void answersCountTest() {
		int numberOfQuestions=questionservice.count();
		when(questiondao.countanswers()).thenReturn(numberOfQuestions);
		assertEquals(numberOfQuestions,questionservice.countanswers());
	}
	@Test
	void getAnswersTest() {
		QuestionsList questionsList=new QuestionsList();
		ArrayList<AnswerDetailsList> answerDetailsList=new ArrayList<>();
		when(questiondao.getAnswers(questionsList.getQuestionid())).thenReturn(answerDetailsList);
		assertEquals(answerDetailsList,questionservice.getAnswers(questionsList.getQuestionid()));
	}
	
	@Test
	void getAllAnswersTest() {
		ArrayList<AnswerDetailsList> answerDetailsList=new ArrayList<>();
		when(questiondao.getAllAnswers()).thenReturn(answerDetailsList);
		assertEquals(answerDetailsList,questionservice.getAllAnswers());
	}
	
	
}
