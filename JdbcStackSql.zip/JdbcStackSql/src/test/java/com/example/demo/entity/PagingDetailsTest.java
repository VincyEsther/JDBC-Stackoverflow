package com.example.demo.entity;



import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class PagingDetailsTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void pagingdetailstest() {
		PagingDetails pagingdetails=new PagingDetails();
		List<PagingList> pagingList=new ArrayList<>();
		pagingdetails.setLimits(3);
		pagingdetails.setTotalnumberofpages(1, 4);
		pagingdetails.setPagingList(pagingList);
		equals(pagingdetails.getLimits());
		equals(pagingdetails.getTotalnumberofpages());
		equals(pagingdetails.getPagingList());
	}

}
