package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class QuestionResponseTest {

	@Test
	void testQuestionResponse() {
		QuestionResponse questionresponse=new QuestionResponse();
		QuestionDetails questionDetails=new QuestionDetails();
		AnswerDetails answerDetails=new AnswerDetails();
		questionresponse.setQuestionDetails(questionDetails);
		questionresponse.setAnswerDetails(answerDetails);
		assertEquals(questionDetails,questionresponse.getQuestionDetails());
		assertEquals(answerDetails,questionresponse.getAnswerDetails());
	}

}
