package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class AnswerDetailsListTest {

	@Test
	void testAnswerDetailsList() {
		AnswerDetailsList answerDetailsList=new AnswerDetailsList();
		answerDetailsList.setAnswerid(1);
		answerDetailsList.setAnswerbody("java program");
		answerDetailsList.setComments("Java");
		assertEquals(1,answerDetailsList.getAnswerid());
		assertEquals("java program",answerDetailsList.getAnswerbody());
		assertEquals("Java",answerDetailsList.getComments());
		
	}

}
