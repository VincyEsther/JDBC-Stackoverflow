package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class MessageTest {

	@Test
	void testMessage() {
		Message message=new Message();
		message.setCode(200);
		message.setType("Created");
		message.setDescription("Question created successfully");
		assertEquals(200,message.getCode());
		assertEquals("Created",message.getType());
		assertEquals("Question created successfully",message.getDescription());
		
	}

}
