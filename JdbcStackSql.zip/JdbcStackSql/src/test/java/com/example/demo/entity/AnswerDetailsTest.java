package com.example.demo.entity;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class AnswerDetailsTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testAnswerDetails() {
		AnswerDetails answerdetails=new AnswerDetails();
		Answers answers=new Answers();
		answerdetails.setAnswers(answers);
		equals(answerdetails.getAnswers());
	}

}
