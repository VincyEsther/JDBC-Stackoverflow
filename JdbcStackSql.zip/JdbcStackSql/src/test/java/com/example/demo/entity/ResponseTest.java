package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ResponseTest {

	@Test
	void testResponse() {
		Response response=new Response();
		Message message=new Message();
		response.setMessage(message);
		assertEquals(message,response.getMessage());
	}

}
