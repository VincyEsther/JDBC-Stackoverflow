package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.dao.QuestionDao;
import com.example.demo.entity.QuestionContract;
import com.example.demo.entity.QuestionDetails;
import com.example.demo.entity.QuestionResponse;
import com.example.demo.entity.Questions;
import com.example.demo.entity.QuestionsList;
import com.example.demo.entity.QuestionsResponse;
import com.example.demo.entity.Response;
import com.example.demo.entity.Service;
import com.example.demo.entity.ServiceContract;
import com.example.demo.entity.TagsList;
import com.example.demo.entity.UserDetails;
import com.example.demo.service.QuestionService;
@SpringBootTest
class QuestionControllerTest {
	@InjectMocks
	private QuestionController questioncontroller;
	@Mock
    private QuestionService questionService;
	@Mock
	private QuestionDao questiondao;
	
	@Test
    void getAllQuestionTest() {
		QuestionContract questionContract=new QuestionContract();
        Questions questions = new Questions();
        QuestionsResponse questionresponse = new QuestionsResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questionslist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();
        int questioncount=questiondao.count();
        questions.setNumberOfQuestions(questioncount);
       questionlist.setQuestionid(1);
        questionlist.setQuestionname("What is java");
        questionlist.setDescription("Java is programing Language");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("John");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        questiondetails.setQuestionsList(questionlist);
        questionresponse.setQuestions(questions);
        questionContract.setQuestionsResponse(questionresponse);
        when(questionService.getAllQuestions(1, 1)).thenReturn(questionslist);
        when(questiondao.count()).thenReturn(questioncount);
        ResponseEntity<Object> response = questioncontroller.getAllQuestions(1,1);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
	@Test
    void getByIdTest() {
		ServiceContract servicecontract=new ServiceContract();
        QuestionResponse questionresponse = new QuestionResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questionslist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();

       questionlist.setQuestionid(1);
        questionlist.setQuestionname("What is java");
        questionlist.setDescription("Java is programing Language");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("John");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        questionslist.add(questionlist);
        questiondetails.setQuestionsList(questionlist);
        questionresponse.setQuestionDetails(questiondetails);
        servicecontract.setQuestionResponse(questionresponse);
       when(questionService.getQuestionsById(questionlist.getQuestionid())).thenReturn(questionlist);
        ResponseEntity<Object> response = questioncontroller.getQuestionsById(questionlist.getQuestionid());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @SuppressWarnings({ "unused", "rawtypes" })
    @Test
    void getByIdTest1() {
        Questions questions = new Questions();
        QuestionsResponse questionresponse = new QuestionsResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questiondetaillist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();
       when(questionService.getQuestionsById(questionlist.getQuestionid())).thenThrow();
        ResponseEntity response = questioncontroller.getQuestionsById(questionlist.getQuestionid());
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
    
    @SuppressWarnings("unused")
	@Test
    void addQuestionTest() {
    	ServiceContract servicecontract=new ServiceContract();
		QuestionDetails questiondetails=new QuestionDetails();
		QuestionResponse questionresponse=new QuestionResponse();
		Service service=new Service();
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(11);
		questionsList.setQuestionname("what is SQL");
		questionsList.setDescription("Questions based on SQL");
		questionsList.setNumberofvotes(21);
		questionsList.setNumberofviews(22);
		questionsList.setNumberofanswers(23);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("vincy",12,23,24,25));
		questiondetails.setQuestionsList(questionsList);
		questionresponse.setQuestionDetails(questiondetails);
		servicecontract.setQuestionResponse(questionresponse);
		service.setServicecontract(servicecontract);
       when(questionService.addQuestion(servicecontract)).thenThrow(IllegalArgumentException.class);
        ResponseEntity<Object> response = questioncontroller.addQuestion(servicecontract);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
	@Test
    void addQuestionTest1() {
    	ServiceContract servicecontract=new ServiceContract();
		QuestionDetails questiondetails=new QuestionDetails();
		QuestionResponse questionresponse=new QuestionResponse();
		Service service=new Service();
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(11);
		questionsList.setQuestionname("what is SQL");
		questionsList.setDescription("Questions based on SQL");
		questionsList.setNumberofvotes(21);
		questionsList.setNumberofviews(22);
		questionsList.setNumberofanswers(23);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("vincy",12,23,24,25));
		questiondetails.setQuestionsList(questionsList);
		questionresponse.setQuestionDetails(questiondetails);
		servicecontract.setQuestionResponse(questionresponse);
		service.setServicecontract(servicecontract);
     when(questionService.addQuestion(servicecontract)).thenThrow(IllegalArgumentException.class);
      ResponseEntity<Object> response = questioncontroller.addQuestion(servicecontract);
      assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }
    @Test
    void addQuestionTest2() {
    	ServiceContract servicecontract=new ServiceContract();
		QuestionDetails questiondetails=new QuestionDetails();
		QuestionResponse questionresponse=new QuestionResponse();
		Service service=new Service();
		QuestionsList questionsList=new QuestionsList();
		questionsList.setQuestionid(11);
		questionsList.setQuestionname("what is SQL");
		questionsList.setDescription("Questions based on SQL");
		questionsList.setNumberofvotes(21);
		questionsList.setNumberofviews(22);
		questionsList.setNumberofanswers(23);
		questionsList.setTagsList(new TagsList("field1","field2"));
		questionsList.setUsersDetails(new UserDetails("vincy",12,23,24,25));
		questiondetails.setQuestionsList(questionsList);
		questionresponse.setQuestionDetails(questiondetails);
		servicecontract.setQuestionResponse(questionresponse);
		service.setServicecontract(servicecontract);
    when(questionService.addQuestion(servicecontract)).thenReturn(servicecontract);
    ResponseEntity<Object> response=questioncontroller.addQuestion(servicecontract);
    assertEquals(HttpStatus.CREATED,response.getStatusCode());
      
    }
    
    
    @Test
    void updateQuestionTest() {
    	QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questionslist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();

       questionlist.setQuestionid(11);
        questionlist.setQuestionname("What is javascript");
        questionlist.setDescription("Question based on javascript");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("Kumar");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        questionslist.add(questionlist);
        questiondetails.setQuestionsList(questionlist);

       when(questionService.updateQuestion(questionlist)).thenReturn(questionlist);
        ResponseEntity<Object> response = questioncontroller.updateQuestion(questionlist);
        assertEquals(HttpStatus.OK, response.getStatusCode());    	
    }
    @SuppressWarnings("unused")
	@Test
    void updateQuestionTest1() {
        Questions questions = new Questions();
        QuestionsResponse questionresponse = new QuestionsResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questiondetaillist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();
       when(questionService.updateQuestion(questionlist)).thenThrow(IllegalArgumentException.class);
        ResponseEntity<Object> response = questioncontroller.updateQuestion(questionlist);
//        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
    @Test
    void deleteQuestionTest() {
    	QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questionslist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();

       questionlist.setQuestionid(21);
        questionlist.setQuestionname("What is oracle");
        questionlist.setDescription("Question based on oracle");
        questionlist.setNumberofvotes(678);
        questionlist.setNumberofviews(456);
        tl.setField1("sql");
        tl.setField2("sql-server");
        questionlist.setTagsList(tl);
        userdetails.setUsername("Lakshmi");
        userdetails.setReputationscore(845);
        userdetails.setNumberofgoldbadges(65);
        userdetails.setNumberofbronzebadges(76);
        userdetails.setNumberofsilverbadges(45);
        questionlist.setUsersDetails(userdetails);
        questionslist.add(questionlist);
        questiondetails.setQuestionsList(questionlist);

       when(questionService.deleteQuestion(21)).thenReturn(questionlist);
        ResponseEntity<Response> response = questioncontroller.deleteQuestion(questionlist.getQuestionid());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    @SuppressWarnings("unused")
	@Test
    void deleteQuestionTest1() {
    	Questions questions = new Questions();
        QuestionsResponse questionresponse = new QuestionsResponse();
        QuestionDetails questiondetails = new QuestionDetails();
        QuestionsList questionlist = new QuestionsList();
        List<QuestionsList> questiondetaillist = new ArrayList<>();
        UserDetails userdetails = new UserDetails();
        TagsList tl= new TagsList();
        when(questionService.deleteQuestion(questionlist.getQuestionid())).thenThrow(IllegalArgumentException.class);
        ResponseEntity<Response> response = questioncontroller.deleteQuestion(questionlist.getQuestionid());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}
