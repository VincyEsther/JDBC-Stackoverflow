package com.example.demo.entity;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class QuestionContractTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testQuestionContract() {
		QuestionContract questioncontract=new QuestionContract();
		QuestionsResponse questionsResponse=new QuestionsResponse();
		questioncontract.setQuestionsResponse(questionsResponse);
		equals(questioncontract.getQuestionsResponse());
	}

}
