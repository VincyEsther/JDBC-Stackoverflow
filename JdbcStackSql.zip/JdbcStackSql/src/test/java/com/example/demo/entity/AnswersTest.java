package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class AnswersTest {

	@Test
	void testAnswers() {
		Answers answers=new Answers();
		List<AnswerDetailsList> answerDetailsList=new ArrayList<>();
		answers.setNumberOfAnswers(5);
		answers.setAnswerDetailsList(answerDetailsList);
		assertEquals(5,answers.getNumberOfAnswers());
		assertEquals(answerDetailsList,answers.getAnswerDetailsList());
		
	}

}
