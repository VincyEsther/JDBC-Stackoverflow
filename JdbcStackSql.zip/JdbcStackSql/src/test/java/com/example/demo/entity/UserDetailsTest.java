package com.example.demo.entity;


import org.junit.jupiter.api.Test;

class UserDetailsTest {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	void testUserDetails() {
		UserDetails userdetails= new UserDetails();
		userdetails.setUsername("Vincy");
		userdetails.setReputationscore(23);
		userdetails.setNumberofgoldbadges(24);
		userdetails.setNumberofbronzebadges(25);
		userdetails.setNumberofsilverbadges(26);
		equals(userdetails.getUsername());
		equals(userdetails.getReputationscore());
		equals(userdetails.getNumberofgoldbadges());
		equals(userdetails.getNumberofbronzebadges());
		equals(userdetails.getNumberofsilverbadges());
	}

}
