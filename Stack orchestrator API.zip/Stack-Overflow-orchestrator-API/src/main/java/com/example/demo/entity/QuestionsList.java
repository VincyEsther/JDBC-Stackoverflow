package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuestionsList {
	private int questionid;
    private String questionname;
    private String description;
    private int numberofvotes;
    private int numberofviews;
    private int numberofanswers;
    private String  createdon;
    private String  modifiedon;
    private TagsList tagsList;
    private UserDetails usersDetails;
	public QuestionsList() {
		super();
	
	}
	public int getQuestionid() {
		return questionid;
	}
	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}
	public String getQuestionname() {
		return questionname;
	}
	public void setQuestionname(String questionname) {
		this.questionname = questionname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getNumberofvotes() {
		return numberofvotes;
	}
	public void setNumberofvotes(int numberofvotes) {
		this.numberofvotes = numberofvotes;
	}
	public int getNumberofviews() {
		return numberofviews;
	}
	public void setNumberofviews(int numberofviews) {
		this.numberofviews = numberofviews;
	}
	public int getNumberofanswers() {
		return numberofanswers;
	}
	public void setNumberofanswers(int numberofanswers) {
		this.numberofanswers = numberofanswers;
	}
	public String getCreatedon() {
		return createdon;
	}
	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}
	public String getModifiedon() {
		return modifiedon;
	}
	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}
	public TagsList getTagsList() {
		return tagsList;
	}
	public void setTagsList(TagsList tagsList) {
		this.tagsList = tagsList;
	}
	public UserDetails getUsersDetails() {
		return usersDetails;
	}
	public void setUsersDetails(UserDetails usersDetails) {
		this.usersDetails = usersDetails;
	}
	
}
