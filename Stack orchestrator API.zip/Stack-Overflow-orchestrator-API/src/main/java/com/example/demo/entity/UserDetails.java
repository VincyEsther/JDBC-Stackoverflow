package com.example.demo.entity;

public class UserDetails {
	private String username;
	  private int reputationscore;
	  private int numberofgoldbadges;
	  private int numberofbronzebadges;
	  private int numberofsilverbadges;
	public UserDetails() {
		super();
	}
	public UserDetails(String username, int reputationscore, int numberofgoldbadges, int numberofbronzebadges,
			int numberofsilverbadges) {
		super();
		this.username = username;
		this.reputationscore = reputationscore;
		this.numberofgoldbadges = numberofgoldbadges;
		this.numberofbronzebadges = numberofbronzebadges;
		this.numberofsilverbadges = numberofsilverbadges;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getReputationscore() {
		return reputationscore;
	}
	public void setReputationscore(int reputationscore) {
		this.reputationscore = reputationscore;
	}
	public int getNumberofgoldbadges() {
		return numberofgoldbadges;
	}
	public void setNumberofgoldbadges(int numberofgoldbadges) {
		this.numberofgoldbadges = numberofgoldbadges;
	}
	public int getNumberofbronzebadges() {
		return numberofbronzebadges;
	}
	public void setNumberofbronzebadges(int numberofbronzebadges) {
		this.numberofbronzebadges = numberofbronzebadges;
	}
	public int getNumberofsilverbadges() {
		return numberofsilverbadges;
	}
	public void setNumberofsilverbadges(int numberofsilverbadges) {
		this.numberofsilverbadges = numberofsilverbadges;
	}
	  

}
