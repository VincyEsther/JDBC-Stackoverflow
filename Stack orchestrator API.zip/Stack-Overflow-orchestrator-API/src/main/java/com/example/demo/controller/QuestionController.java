package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.example.demo.entity.QuestionsList;

import reactor.core.publisher.Mono;
@RequestMapping("/questions")
@RestController
public class QuestionController {
@Autowired
 private Builder WebClient;


@PostMapping("/Question1")
public Object saveOrUpdateQuestions(@RequestBody QuestionsList question){        
  try {

        String url = "http://localhost:8080/questions/addQuestions";
        return WebClient.build().post().uri(url).body(Mono.just(question), QuestionsList.class).retrieve().bodyToMono(Object.class).block();    



  } 
  catch (Exception e) {            
        String url = "http://localhost:8080/questions/editQuestions";
        return WebClient.build().put().uri(url).body(Mono.just(question), QuestionsList.class).retrieve().bodyToMono(Object.class).block();
     }  
}
}






